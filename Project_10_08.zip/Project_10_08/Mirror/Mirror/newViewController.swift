//
//  newViewController.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MediaPlayer

class newViewController: UIViewController {
    
    var moviePlayer: MPMoviePlayerController?
    var player: MPMoviePlayerController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        playVideo()
       self.view.removeFromSuperview()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    func playVideo() {
        
        let path = Bundle.main.path(forResource: "intro", ofType:"mp4")
        
        
        
        
        //let  path = Bundle.main.path(forResource: "intro", ofType: "mp4", inDirectory: "main")
        
        let url = NSURL.fileURL(withPath: path!)
        moviePlayer = MPMoviePlayerController(contentURL: url)
        if let player = moviePlayer {
            player.view.frame = self.view.bounds
            player.controlStyle = .none
            player.prepareToPlay()
            player.scalingMode = .aspectFit
            self.view.addSubview(player.view)
        }
    }
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


