//
//  SignUpVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet var segGender: UISegmentedControl!
    @IBOutlet var pickDOB: UIDatePicker!
    @IBOutlet var pickCity: UIPickerView!
    
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtContactNumber: UITextField!
    @IBOutlet var txtAddress: UITextField!
    @IBOutlet var txtPostalCode: UITextField!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var txtConfirmPassword: UITextField!
    
    var cityList : [String] = ["Toronto", "Vancouver", "Edmenton", "Brampton", "Jasper", "Ottawa", "Calgery", "Banff"]
    var selectedCityIndex : Int = 0
    var gender: String = ""
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: true)
        self.title = "Sign Up"
        
        let btnDone = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(btnSubmit))
        self.navigationItem.rightBarButtonItem = btnDone
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pickCity.dataSource = self
        pickCity.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func btnSubmit() {
        var data : String = txtName.text!
        data += "\n" + txtContactNumber.text!
        data += "\n" + txtAddress.text!
        data += "\n" + txtPostalCode.text!
        data += "\n" + txtEmail.text!
        data += "\n" + txtPassword.text!
        data += "\n" + txtConfirmPassword.text!
        data += "\n \(pickDOB.date)"
        
        selectedCityIndex = pickCity.selectedRow(inComponent: 0)
        data += "\n \(cityList[selectedCityIndex])"
        
        switch segGender.selectedSegmentIndex {
        case 0:
            data += "\n Male"
            gender = "Male"
        case 1:
            data += "\n Female"
            gender = "Female"
        case 2:
            data += "\n No Disclosure"
            gender = "No Disclosure"
        default:
            data += "\n No Disclosure"
            gender = "No Disclosure"
        }
        
        let infoAlert = UIAlertController(title: "Confirm details", message: data, preferredStyle: .alert)
        
        if txtPassword.text != txtConfirmPassword.text{
            infoAlert.message = "Both passwords must be same"
        }else{
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayHomeVC()}))
        }
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    
    //methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cityList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return cityList[row]
    }
    
    func displayHomeVC(){
        let newUser = User(txtName.text!, txtAddress.text!, txtContactNumber.text!, txtPostalCode.text!, cityList[pickCity.selectedRow(inComponent: 0)],
                           txtEmail.text!, txtPassword.text!, self.gender, pickDOB.date)
        
        if User.addUser(newUser: newUser){
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
            navigationController?.pushViewController(homeVC, animated: true)
        }else{
            let infoAlert = UIAlertController(title: "Unsuccessful", message: "Account Creation Unsuccessful", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
