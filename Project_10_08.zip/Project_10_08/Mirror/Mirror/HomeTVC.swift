//
//  HomeTVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

struct Recipe {
    
    let name: String
    let thumbnails: String
    let prepTime: String
}
class HomeTVC: UITableViewController {
    
    var recipes = [Recipe]()
    let identifier: String = "tableCell"

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 200
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .done, target: self, action: nil)
        navigationItem.title = "Recipes"
        initializeTheRecipes()
    }
    
    func initializeTheRecipes() {
        self.recipes = [Recipe(name: "Egg Benedict", thumbnails: "egg_benedict.jpg", prepTime: "1 hour"),
                        Recipe(name: "Mushroom Risotto", thumbnails: "mushroom_risotto.jpg", prepTime: "30 min"),
                        Recipe(name: "Full Breakfast", thumbnails: "full_breakfast.jpg", prepTime: "25 min"),
                        Recipe(name: "Hamburger", thumbnails: "hamburger.jpg", prepTime: "15 min"),
                        Recipe(name: "Ham and Egg Sandwich", thumbnails: "ham_and_egg_sandwich.jpg", prepTime: "20 min"),
                        Recipe(name: "Creme Brelee", thumbnails: "creme_brelee.jpg", prepTime: "10 min"),
                        Recipe(name: "White Chocolate Donut", thumbnails: "white_chocolate_donut.jpg", prepTime: "1 hour"),
                        Recipe(name: "Starbucks Coffee", thumbnails: "starbucks_coffee.jpg", prepTime: "2 hour"),
                        Recipe(name: "Vegetable Curry", thumbnails: "vegetable_curry.jpg", prepTime: "50 min"),
                        Recipe(name: "Instant Noodle with Egg", thumbnails: "instant_noodle_with_egg.jpg", prepTime: "65 min"),
                        Recipe(name: "Noodle with BBQ Pork", thumbnails: "noodle_with_bbq_pork.jpg", prepTime: "40 min"),
                        Recipe(name: "Japanese Noodle with Pork", thumbnails: "japanese_noodle_with_pork.jpg", prepTime: "30 min"),
                        Recipe(name: "Green Tea", thumbnails: "green_tea.jpg", prepTime: "25 min"),
                        Recipe(name: "Thai Shrimp Cake", thumbnails: "thai_shrimp_cake.jpg", prepTime: "1.5 hour"),
                        Recipe(name: "Angry Birds Cake", thumbnails: "angry_birds_cake.jpg", prepTime: "2 hour"),
                        Recipe(name: "Ham and Cheese Panini", thumbnails: "ham_and_cheese_panini.jpg", prepTime: "35 min")]
        
        self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
       // return TableItems.titles.count
        
         return recipes.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeCell", for: indexPath) as! HomeTVCell
//
//        // Configure the cell...
//        cell.lblTitle.text = TableItems.titles[indexPath.row]
//        cell.lblSubtitle.text = TableItems.subTitles[indexPath.row]
//        cell.imgHome.image = UIImage(named: TableItems.images[indexPath.row])
//
//        return cell
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? TableCell {
            cell.configurateTheCell(recipes[indexPath.row])
            
            return cell
        }
        return UITableViewCell()
        
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            recipes.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .bottom)
        }
    }
    
    // MARK: Segue Method
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "recipeDetail",
            let indexPath = self.tableView?.indexPathForSelectedRow,
            let destinationViewController: DescriptionVC = segue.destination as? DescriptionVC
        {
            destinationViewController.recipe = recipes[indexPath.row]
        }
    }
    
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
////         let infoAlert = UIAlertController ( title: "menu action", message: TableItems.titles[indexPath.row], preferredStyle: .alert)
////        infoAlert.addAction(UIAlertController(title: "so what", message: "chil ", preferredStyle: .alert)
////
////        self.present(infoAlert,animated: true, completion: nil)
//
//
//        switch indexPath.row {
//        case 0:
//            print("one")
//        case 1:
//
//            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            let descVC = mainSB.instantiateViewController(withIdentifier: "DescriptionScene")
//            //self.present(homeVC, animated: true, completion: nil)
//            navigationController?.pushViewController(descVC, animated: true)
//
//            print("2")
//        case 2:
//            print("3")
//        case 3:
//                print("4")
//                let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                let webvc = mainSB.instantiateViewController(withIdentifier: "WebScene")
//                //self.present(homeVC, animated: true, completion: nil)
//                navigationController?.pushViewController(webvc, animated: true)
//        case 4:
//            print("5")
//        case 5:
//            print("6")
//        case 6:
//            print("7")
//        case 7:
//            print("8")
//        case 8:
//            print("8")
//        case 9:
//                print("10")
//        case 10:
//            print("11")
//
//        default:
//            print("no action")
//        }
//    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
