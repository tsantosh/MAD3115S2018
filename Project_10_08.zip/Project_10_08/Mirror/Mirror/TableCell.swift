//
//  TableCell.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit


class TableCell: UITableViewCell {

    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var prepTimeLabel: UILabel!
    @IBOutlet var thumbnailImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configurateTheCell(_ recipe: Recipe)
    {
        self.nameLabel.text = recipe.name
        self.prepTimeLabel.text = "Prep Time: " + recipe.prepTime
        self.thumbnailImageView.image = UIImage(named: recipe.thumbnails)
    }

}
