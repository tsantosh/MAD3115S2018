//
//  User.swift
//  Day2
//
//  Created by MacStudent on 2018-08-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class User {
    var name: String!
     var contactNumber: String!
     var address: String!
     var postalCode: String!
     var city: String!
     var email: String!
     var password: String!
     var dob: Date!
     var gender: String!
    private static var userList = [String: User]()
    
    init() {
      
        self.name  = ""
        self.contactNumber  = ""
        self.address   = ""
        self.postalCode   = ""
        self.city   = ""
        self.email  = ""
        self.password = ""
        self.dob  = Date()
        self.gender  = ""
        
        
    }
    
    init(_ name: String, _ address : String, _ ContactNumber: String, _ postalCode:String, _ city: String, _ email: String, _ password: String, _ gender: String, _dob: Date) {
        
        self.name = name
        self.contactNumber = ContactNumber
        self.address = address
        self.postalCode = postalCode
        self.city = city
        self.email = email
        
        self.password = password
        self.dob = Date()
        self.gender = gender
        
    }
    
    static func addUser(newUser: User) -> Bool {
        if self.userList[newUser.email] == nil {
            self.userList[newUser.email] = newUser
            return true
        }
        
        return false
        
        
    }
    static func getAllUsers() -> [String: User] {
     return userList
    }
    static func searchUser(userEmail: String) -> User {
        if self.userList[userEmail] !== nil {
           return self.userList[userEmail]!
            
        }
        return User()
    
}
}
